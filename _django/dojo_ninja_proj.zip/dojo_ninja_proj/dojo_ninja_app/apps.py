from django.apps import AppConfig


class DojoNinjaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dojo_ninja_app'
